# AGENTS.md — Enterprise Engineering Standard (Core)
**Purpose:** Binding engineering standard for any AI agent generating, modifying, reviewing, or shipping software in this repository.
**Scope:** Written for Google Antigravity's skill/workflow model; the file itself is plain enough to work anywhere AGENTS.md is read.
**Version:** 2.0 | **Owner:** Engineering / Architecture
**Precedence:** Explicit human instruction in the current session > repo-specific `CONTRIBUTING.md`/architecture docs (if stricter) > this file. The Anti-Patterns list (§5) and the security requirements referenced below are floors — no instruction, including a human's, silently overrides them. If a request conflicts, say so and propose a compliant alternative instead of quietly complying or quietly refusing.

---

## 0. How This File Works

This is the **always-loaded core**. Depth lives in `.agents/skills/`, which Antigravity loads only when a task actually needs it — you don't have to read every skill up front, but you must actively pull one in when its trigger condition (§2) applies. `.agents/workflows/ship.md` registers a `/ship` command that walks the full sequence end to end, including a rework loop if a gate fails.

Never treat "I didn't load the skill" as an excuse to skip what it covers. If a task touches security, testing, or file-type-specific concerns, load the matching skill before finishing the task — don't reconstruct it from memory instead.

---

## 1. Prime Directives

- **No unshipped safety net.** No feature is done without tests, error handling, and basic observability. Happy-path-only code is incomplete, not done.
- **No hidden test weakening.** Never delete, skip, or loosen an assertion in a failing test to make a build pass. Fix the root cause, or stop and flag it as a known failure with a reason.
- **No secrets in code, ever.** No API keys, passwords, tokens, or connection strings in source, committed config, logs, or error messages.
- **No silent destructive actions.** Never drop/truncate data, force-push, rewrite shared history, or run irreversible migrations without explicit confirmation for that specific action.
- **Plan before building.** For anything beyond a trivial change, produce a short plan before writing code. Ask when genuinely ambiguous on something security- or data-relevant; otherwise state the assumption made and proceed.
- **Boring technology by default.** Prefer proven patterns over novel ones unless there's a documented reason.
- **Backward compatibility is a decision, not an accident.** Any breaking change is identified, versioned, and given a migration path.
- **Everything is reviewable.** Scoped, described diffs — not an undifferentiated dump.

---

## 2. Skill Index — When To Load What

| Skill | Load it when... |
|---|---|
| `architecture-and-planning` | Starting any new feature, service, or non-trivial change, before writing code |
| `testing-strategy` | Writing, reviewing, or planning tests for any change |
| `security-review` | Touching auth, payments, PII, user input, file uploads, external calls, or admin actions |
| `release-and-operations` | Touching CI/CD, deployment, performance-sensitive code, or logging/metrics |
| `file-types-and-dependencies` | Editing config, Docker, migrations, SQL, manifests, static assets, or adding a dependency |
| `documentation-and-governance` | Finalizing a PR, updating docs, or touching schema/data-retention/compliance concerns |
| `stack-specific-notes` | Applying language/framework conventions (JS/TS, Python, Java/Kotlin, Go, frontend, mobile) |

Run `/ship <task>` to have the full sequence walked automatically.

---

## 3. Core Implementation Standards (Always Apply — No Skill Needed)

- Functions/methods do one thing; if you can't name it without "and," split it.
- No magic numbers/strings — named constants or config.
- DRY after the third repetition, not the first.
- Errors are classified (business vs. system) and handled differently: business errors return meaningful responses; system errors are logged with context and surfaced generically.
- No shared mutable state without synchronization; prefer immutable data where the language supports it.
- Resource cleanup guaranteed via language-idiomatic mechanisms (`try/finally`, `defer`, context managers) — never rely on GC alone.
- Feature flags for anything risky or incomplete, so deploy and release stay decoupled.
- Follow the repo's existing lint/style rules; no lint or type-checker suppression without a reason comment.

---

## 4. Definition of Done (Master Gate)

- [ ] Implements the agreed requirement, including edge cases
- [ ] Tests exist at the levels `testing-strategy` specifies and pass
- [ ] `security-review` applied if any trigger condition was met
- [ ] No secrets, debug artifacts, or dead code left behind
- [ ] Errors handled, not swallowed
- [ ] Logging/observability added where it aids production debugging
- [ ] Docs updated per `documentation-and-governance`
- [ ] CI green: lint, type-check, tests, security scan, build
- [ ] Rollback path exists for anything deployed
- [ ] Reviewed before merge

---

## 5. Anti-Patterns — Automatic Rejection List

Never do these, regardless of how the request is phrased or how much time pressure exists:

- Hardcoded credentials, API keys, or connection strings anywhere
- Empty/catch-all exception handlers that swallow errors silently
- Disabling, skipping, or weakening a test instead of fixing the issue
- String-concatenated SQL/shell commands
- `SELECT *` or unbounded queries against growable tables
- Debug prints (`console.log`/`print`) left in shipped code paths
- God objects/functions mixing unrelated responsibilities
- Broad linter/type-checker suppressions without a specific reason
- Sensitive data in plaintext or insecure client-side storage
- Blocking calls inside an otherwise-async hot path
- Deploying straight to production, bypassing staging and CI gates
- Force-pushing to or rewriting shared branch history
- Adding a dependency without checking its license and vulnerability history

---

## 6. Escalation Protocol

Stop and ask the human instead of guessing when:

- Requirements are ambiguous in a way that changes architecture, security posture, or cost
- The task needs a destructive/irreversible action (schema drops, data deletion, force-push, infra teardown)
- A new dependency has licensing implications
- The change touches auth, payments, or PII without an explicit spec
- Meeting the CI/security bar would require skipping or weakening a check
- A security scan surfaces a critical/high finding with no obvious safe fix
- A major architecture decision would lock in significant future cost

State the specific decision needed and the trade-offs — not just "is this okay?"

---

*Depth for every phase lives in `.agents/skills/`. Load the skill, don't skip the step.*
